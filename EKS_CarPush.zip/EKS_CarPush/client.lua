local pushing = false
local vehicle = nil

local blockedClasses = {
    [10] = true, -- Boats
    [11] = true, -- Helicopters
    [12] = true, -- Planes
    [16] = true, -- Service
    [19] = true, -- Military
    [20] = true, -- Commercial (Lorries)
    [21] = true  -- Trains
}

function LoadAnim(dict)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(10) end
end

function StopPush()
    local ped = PlayerPedId()
    DetachEntity(ped, true, false)
    ClearPedTasksImmediately(ped)
    pushing = false
    vehicle = nil
    SetEntityCollision(ped, true, true)
end

function StartPush(veh)
    if pushing then return end
    pushing = true
    vehicle = veh

    local ped = PlayerPedId()
    LoadAnim("missfinale_c2ig_11")

    TaskPlayAnim(ped, "missfinale_c2ig_11", "pushcar_offcliff_m", 8.0, -8.0, -1, 1, 0, false, false, false)

    local min, _ = GetModelDimensions(GetEntityModel(veh))
    local isBike = IsThisModelABike(GetEntityModel(veh))
    local offsetY = isBike and (min.y - 0.3) or (min.y - 0.7)
    local offsetZ = isBike and 0.4 or 0.7

    AttachEntityToEntity(ped, veh, GetPedBoneIndex(ped, 0), 0.0, offsetY, offsetZ, 0.0, 0.0, 0.0, false, false, true, false, 2, true)
    SetEntityHeading(ped, GetEntityHeading(veh))
    SetEntityCollision(ped, false, true)

    CreateThread(function()
        while pushing do
            Wait(0)

            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 21, true)
            DisableControlAction(0, 22, true)

            local speed, turn = 0.0, 0.0
            if IsControlPressed(0, 32) then speed = 1.0 end -- W
            if IsControlPressed(0, 33) then speed = -0.8 end -- S
            if IsControlPressed(0, 34) then turn = 15.0 end -- A
            if IsControlPressed(0, 35) then turn = -15.0 end -- D

            SetVehicleForwardSpeed(vehicle, speed)
            SetVehicleSteeringAngle(vehicle, turn)

            if IsControlJustReleased(0, 73) then -- X to cancel
                StopPush()
            end
        end
    end)
end

CreateThread(function()
    exports.ox_target:addGlobalVehicle({
        {
            name = 'push_vehicle',
            icon = 'fa-solid fa-car',
            label = 'Push Vehicle',
            distance = 2.0,
            bones = { 'boot', 'bumper_r', 'seat_r', 'misc_b' }, -- Add bike-compatible rear bones
            canInteract = function(entity)
                local class = GetVehicleClass(entity)
                return not pushing and not blockedClasses[class]
            end,
            onSelect = function(data)
                local entity = data.entity
                if DoesEntityExist(entity) then
                    StartPush(entity)
                end
            end
        }
    })
end)
