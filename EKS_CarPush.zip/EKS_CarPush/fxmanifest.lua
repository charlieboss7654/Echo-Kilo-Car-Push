fx_version 'cerulean'
game 'gta5'

author 'R.Robertson - Echo Kilo Studios'
description 'Vehicle Pushing Script!'
version '1.0.0'

client_script 'client.lua'

dependencies {
    'ox_target'
}
